package Laba_5.Laba_5_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Library {

    public static long booksNumber = 10000;
    public long magazinesNumber;
    public long newsPaperNumber;
    private List<Book> booksList = new LinkedList<>();


    Library(){
        String filePath = "C:\\Users\\stefn\\IdeaProjects\\Labs\\src\\Laba_5\\Laba_5_1\\books.txt";
        File file = new File(filePath);
        try {
            Scanner in = new Scanner(file);
            StringBuilder booksInfo = new StringBuilder();
            while(in.hasNext()) {
                booksInfo.append(in.nextLine() + "\n");
            }
            for(String bookInfo : booksInfo.toString().split("\n")) {
                String [] temp = bookInfo.split("-");
                booksList.add(new Book(temp[0], temp[1], temp[2], Integer.parseInt(temp[3])));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


        this.magazinesNumber = 2000;
        this.newsPaperNumber = 1500;


    }

    Library(long magazinesNumber, long newsPaperNumber){

        this.magazinesNumber = magazinesNumber;
        this.newsPaperNumber = newsPaperNumber;
    }


    public void givenList_Library() {
        Random rand = new Random();
        List<String> givenList = Arrays.asList("один", "два", "три", "четыре", "десять", "двадцать");

        int numberOfElements = 1;

        for (int i = 0; i < numberOfElements; i++) {
            int randomIndex = rand.nextInt(givenList.size());
            String randomElement = givenList.get(randomIndex);
            System.out.println("количество отзывов: " + randomElement);
        }

    }

    public void showInfo(){

        System.out.println("количество книг: " + booksNumber);
        System.out.println("Количество журналов: " + magazinesNumber);
        System.out.println("количество газет: " + newsPaperNumber);
        System.out.println();
    }

    /*public String ListLibrary(String addBook){
        return
    }*/
}
