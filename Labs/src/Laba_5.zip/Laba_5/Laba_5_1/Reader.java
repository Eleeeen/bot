package Laba_5.Laba_5_1;

import static Laba_5.Laba_5_1.Library.booksNumber;

public class Reader {

    static int readerCount;
    public int bookCount;
    String readerName;
    int readerAge;

    String readerBookName;
    String readerAuthorName;

    int readerBookReleaseYear;

    Reader(){
        this.readerName = "Zaur";
        this.readerAge = 30;
        this.readerBookName = "100 лет одиночества";
        this.readerAuthorName = "Габриэль Гарсиа Маркес";
        this.readerBookReleaseYear = 2012;
        this.bookCount = 0;
        readerCount++;
    }

    Reader(String name, int age, String bookName, String authorName, int BookReleaseYear){
        this.readerName = name;
        this.readerAge = age;
        this.readerBookName = bookName;
        this.readerAuthorName = authorName;
        this.readerBookReleaseYear = BookReleaseYear;
        this.bookCount = 0;
        readerCount++;
    }

    public void showInfo(){

        System.out.println("Ваше имя: " + readerName);
        System.out.println("Ваш возраст: " + readerAge);
        System.out.println("Название автора: " + readerAuthorName);
        System.out.println("Название книги: " + readerBookName);
        System.out.println();
    }

    public void Info(){
        System.out.println("Выберите операцию:" + "\n" +
                "1 - Год выпуска книги, которая за Вами закреплена" + "\n" + "2 - Вся информация" + "\n" +
                "3 - количество книг в наличии" + "\n" + "4 - выход");
    }

    void BookReturn(){
        int i = 0;
        while (this.readerBookReleaseYear >= this.readerBookReleaseYear - 10){
            if (bookCount <= 12){
                booksNumber--;
                bookCount++;
                i++;
            }
            else {
                 break;
            }

        }

    }

    public int showInfo(int choice){

        switch (choice){
            case 1:
                System.out.println("Год выпуска книги, которая за Вами закреплена: " + readerBookReleaseYear);
                break;
            case 2:
                showInfo();
                break;
            case 3:
                System.out.println("Взято всего книг: " + bookCount);
                break;
            case 4:
                System.out.println("До новых встреч, " + readerName + "!");
                break;
            default:
                System.out.println("Некорректный запрос");
                break;
        }
        return 0;
    }


}
