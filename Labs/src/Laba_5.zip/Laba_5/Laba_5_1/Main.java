package Laba_5.Laba_5_1;
import java.util.Scanner;
import static Laba_5.Laba_5_1.Librarian.*;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        showHello();

        Library library = new Library();
        Librarian lib = new Librarian();
        Reader red = new Reader();

        System.out.println("БИБЛИОТЕКА: ");
        library.showInfo();
        library.givenList_Library();

        System.out.println();
        System.out.println("БИБЛИОТЕКАРЬ: ");
        lib.showInfo();

        System.out.println("ЧИТАТЕЛЬ 1: ");

        red.BookReturn();
        red.showInfo();
        System.out.println();
        red.Info();

        int input = in.nextInt();
        red.showInfo(input);

      /*  System.out.println("ЧИТАТЕЛЬ 2: ");
        Reader red2 = new Reader("Алиса", 24, "451 градус по Фаренгейту", "Рэй Брэдбери",1953);
        red2.BookReturn();

        red2.Info();
        int input2 = in.nextInt();
        red2.showInfo(input2);

        System.out.println("ЧИТАТЕЛЬ 3: ");
        Reader red3 = new Reader("Олег", 38, "А зори здесь тихие, тихие...", "Борис Васильев",1969);
        red3.BookReturn();

        red3.Info();
        int input3 = in.nextInt();
        red3.showInfo(input3);

        System.out.println();
        System.out.println("БИБЛИОТЕКА: ");
        library.givenList_Library();
        library.showInfo();

        System.out.println(); */
        System.out.println("НОВЫЙ БИБЛИОТЕКАРЬ: ");
        Librarian lib2 = new Librarian("Диана", 20, "Красное и черное", "Стендаль", 1830);
        myName = "Диана";
        System.out.println("Введите номер опрерации: ");

        int input4 = in.nextInt();
        lib2.showInfo(input4);

        System.out.println("Увеличение зп");
        double salPlus = in.nextDouble();
        System.out.println(lib2.increaseSalary(salPlus));

        System.out.println("Уменьшение зп");
        double salMinus = in.nextDouble();
        System.out.println(lib2.decreaseSalary(salMinus));
    }





}
