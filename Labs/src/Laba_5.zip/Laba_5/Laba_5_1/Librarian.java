package Laba_5.Laba_5_1;

import static Laba_5.Laba_5_1.Library.booksNumber;
import static Laba_5.Laba_5_1.Reader.readerCount;

public class Librarian {
    public static String myName = "Eleeeen";

    double salary = 1000;
    int myAge;

    String librarianName;

    String bookName;
    String authorName;

    int bookReleaseYear;

    Librarian(){

        this.myAge = 19;
        this.bookName = "Inferno";
        this.authorName = "Den Brown";
        this.bookReleaseYear = 2013;
    }

    Librarian(String librarianName, int age, String bookName, String authorName, int bookReleaseYear){
        this.librarianName = librarianName;
        myName = librarianName;
        this.myAge = age;
        this.bookName = bookName;
        this.authorName = authorName;
        this.bookReleaseYear = bookReleaseYear;
    }

    public double increaseSalary(double plus){
        salary+=plus;
        return salary;
    }

    public double decreaseSalary(double plus){
        salary-=plus;
        return salary;
    }

    public void showInfo(){

        System.out.println("Ваше имя: " + myName);
        System.out.println("Ваш возраст: " + myAge);
        System.out.println("Название читаемой книги: " + bookName);
        System.out.println("Автор: " + authorName);
        System.out.println();
    }

    public int showInfo(int choice){

        switch (choice){
            case 1:
                showInfo();
                break;
            case 2:
                System.out.println("книг в библиотеке: " + booksNumber);
                break;
            case 3:
                System.out.println("До новых встреч, " + myName + "!");
                break;
            case 4:
                System.out.println("Количество читателей: " + readerCount);
            default:
                System.out.println("Некорректный запрос");
                break;
        }
        return 0;
    }

    public static void showHello(){
        System.out.println(myName + ", добро пожаловать в библиотеку!");
        System.out.println();
    }

}
