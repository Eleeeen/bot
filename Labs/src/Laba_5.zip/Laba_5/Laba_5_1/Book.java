package Laba_5.Laba_5_1;

public class Book {
    private String name;
    private String author;
    private String genre;
    private int pages;

    public Book(String name, String author, String genre, int pages) {
        this.name = name;
        this.author = author;
        this.genre = genre;
        this.pages = pages;
    }

    public void getInfo() {
        System.out.println(
                "Name: " + name + "\n" +
                "Author: " + author + "\n" +
                "Genre: " + genre + "\n" +
                "Pages: " + pages
        );
    }

    @Override
    public String toString() {
        return name;
    }
}
