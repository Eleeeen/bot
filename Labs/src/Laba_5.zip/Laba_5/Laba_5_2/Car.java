package Laba_5.Laba_5_2;

public class Car {
    String name;
    public Car(String name) {
        this.name = name;
    }
/*    @Override
    public String toString() {
        return name;
    }*/
}
